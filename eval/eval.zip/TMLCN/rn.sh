#!/bin/bash

sudo make stop
sudo make clean
sudo make run
#atom --no-sandbox ./logs/s1.log
