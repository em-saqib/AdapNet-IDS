#!/bin/bash

rm flows_tr.csv
rm flows_ts.csv

python3 "splitData.py"

sleep 1

./retrain.sh

sleep 1

#simple_switch_CLI --thrift-port 9090 < rules.cmd
#atom --no-sandbox ./logs/s1.log


# parallel ::: "sudo python3 send.py flows_ts.csv" "python3 monitoring.py" "python3 modelUpdate.py"

parallel ::: "sudo python3 send.py flows_ts.csv" "python3 monitoring.py"
