import pandas as pd
import csv

df = pd.read_csv("flows_cicids2017.csv")
# df = pd.read_csv("flows_nb2015.csv")

#Split for illustration only
# df_train = df.iloc[0:30000]
# df_test = df.iloc[67000:72000]



# Split for final euavlation
df_train = df.iloc[0:6000]
df_test = df.iloc[6000:60000]

df_train.to_csv("flows_tr.csv", index=False)
df_test.to_csv("flows_ts.csv", index=False)
