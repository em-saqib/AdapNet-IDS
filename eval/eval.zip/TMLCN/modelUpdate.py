import time
import pandas as pd
import subprocess


# Function to read the current accuracy from 'current_accuracy.txt'
def read_accuracy():
    try:
        with open('current_accuracy.txt', 'r') as accuracy_file:
            accuracy = float(accuracy_file.read().strip())
        return accuracy
    except FileNotFoundError:
        return None

# Function to concatenate buffer with external CSV file
def concatenate_buffer_with_csv(buffer, csv_file):
    try:
        # Read the external CSV file
        external_data = pd.read_csv(csv_file)

        # Concatenate the buffer with the external data
        combined_data = pd.concat([external_data, buffer], ignore_index=True)

        # Save the combined data back to the CSV file
        combined_data.to_csv(csv_file, index=False)

        print(f"Concatenated buffer with {csv_file}")
        print("Updated length : ", combined_data.shape)
    except FileNotFoundError:
        print(f"External data file '{csv_file}' not found.")

def retrain_model():
    print("\n Model retraining started...")
    # Run the shell script for model retraining
    script_path = "retrain.sh"
    try:
        subprocess.run(["bash", script_path], check=True)
        print("Model is successfully retrained.")
    except subprocess.CalledProcessError as e:
        print(f"Error with model retraining: {e}")


def main():

    buffer_enabled = False
    buffer = pd.DataFrame(columns=['sport', 'dsport', 'Label'])
    status = 0  # 0: Everything good, 1: Start buffering, 2: Model update
    false_alarm_count = 0
    buffer_size_drift = 500
    max_buffer_size = 2000
    DRIFT_WARN = 0.99
    DRIFT_THR = 0.96

    model_update_count = 0

    print("Model monitoring script started")

    while True:
        accuracy = read_accuracy()
        if accuracy is not None:
            print(f"Current Accuracy: {accuracy}")

            if status == 0 and accuracy < DRIFT_WARN:
                print("Start Buffering...")
                buffer_enabled = True
                status = 1
            elif status == 1 and accuracy >= DRIFT_WARN:
                print("False Alarm")
                false_alarm_count += 1
                buffer_enabled = False
                status = 0
                buffer = pd.DataFrame(columns=['sport', 'dsport', 'Label'])
            elif status == 1 and accuracy < DRIFT_THR:
                status = 2
                print("Drift Alert")
                concatenate_buffer_with_csv(buffer, 'flows_tr.csv')  # Concatenate buffer when there's a drift alert
                buffer = pd.DataFrame(columns=['sport', 'dsport', 'Label'])

        if buffer_enabled:
            # Read data from the external text file and append it to the buffer
            try:
                with open('sending_flows_data.txt', 'r') as external_data_file:
                    lines = external_data_file.readlines()
                    for line in lines:
                        line = line.strip().split(',')
                        if len(line) == 3:
                            buffer.loc[len(buffer)] = line
                    print("Buffering data...")
                    print(f"Buffer Size: {buffer.shape[0]}")

                    if status == 2 and buffer.shape[0] >= buffer_size_drift:
                        print("Model Updates by Drift Alert")
                        retrain_model()
                        model_update_count += 1

                        concatenate_buffer_with_csv(buffer, 'flows_tr.csv')
                        buffer = pd.DataFrame(columns=['sport', 'dsport', 'Label'])
                        status = 1  # Resume buffering
                        buffer_enabled = True  # Resume buffering

                    if buffer.shape[0] >= max_buffer_size:
                        print("Model Updates by Max Buffer")
                        retrain_model()
                        model_update_count += 1

                        concatenate_buffer_with_csv(buffer, 'flows_tr.csv')
                        buffer = pd.DataFrame(columns=['sport', 'dsport', 'Label'])
                        status = 1  # Resume buffering
                        buffer_enabled = True

            except FileNotFoundError:
                print("External data file not found.")

        # Place your code for updating the model or other tasks here

        # Sleep for a while before checking accuracy again
        time.sleep(1)

if __name__ == '__main__':
    main()
