#!/bin/bash

# Train model
python3 Machinelearning.py -i flows_tr.csv -o tree.txt

sleep 1

python3 converter.py

sleep 1

simple_switch_CLI --thrift-port 9090 < rules.cmd
